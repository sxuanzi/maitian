package com.example.lenovo.maitianzhuce.parents_jiemian.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.teacher_Fragment.DynamiceFragment;
import com.hjm.bottomtabbar.BottomTabBar;

/**
 * Created by lenovo on 2017/12/10.
 */

public class TeacherJm extends AppCompatActivity {

    private BottomTabBar mBottomBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //隐藏安卓自带标题栏
        ActionBar actionbar = getSupportActionBar();
        if (actionbar !=null){actionbar.hide();}

        setContentView(R.layout.botton_navigation);
        mBottomBar = (BottomTabBar) findViewById(R.id.bottom_tab_bar);
        setBottonNavigation();//调用底部导航栏方法  进行导入

    }

    //设置底部导航栏
    private  void setBottonNavigation(){

        mBottomBar.init(getSupportFragmentManager())
                .setChangeColor(Color.GRAY, Color.WHITE)
                .addTabItem("动 态", R.drawable.dongtai, DynamiceFragment.class)
                .addTabItem("教师", R.drawable.teacher, DynamiceFragment.class)
                .addTabItem("资助情况", R.drawable.zizu, DynamiceFragment.class)
                //添加选项卡切换监听
                .setOnTabChangeListener(new BottomTabBar.OnTabChangeListener() {
                    @Override
                    public void onTabChange(int position, String name) {
                        //这里不用说，你们也都看的懂了
                        //暂时就返回了这俩参数，如果还有什么用的比较多的参数，欢迎留言告诉我，我继续添加上
                        Log.i("TGA", "位置：" + position + "      选项卡的文字内容：" + name);
                    }
                });

    }

}
