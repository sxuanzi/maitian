package com.example.lenovo.maitianzhuce.parents_jiemian.lover_Fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.LoverAdapter;
import com.example.lenovo.maitianzhuce.parents_jiemian.fruit_txt;

import java.util.ArrayList;
import java.util.List;

/*点击动态包裹的碎片跳转到此页面
这个页面包裹的是标题栏
 */

public class DynamiceFragment extends Fragment {

    private List<fruit_txt> loverlist = new ArrayList<>();
    private SwipeRefreshLayout swiperefresh;
    private ArrayList<String> imagePaths = new ArrayList<>();

    LoverAdapter adapter;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //把动态的主页面传给view
        View view = inflater.inflate(R.layout.lover_dynamics_main,null);
        initData(view);
        sss(view);
        //调用实现动态RecyclerView布局

        return view;
    }

    public void initData(View view){
        //初始化控件，源数据
        initFruits();
        RecyclerView recycleView = view.findViewById(R.id.lover_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recycleView.setLayoutManager(layoutManager);
        adapter=new LoverAdapter(loverlist,getActivity());
        recycleView.setAdapter(adapter);
    }

    private void initFruits(){
        for (int i=0;i<10;i++){
            fruit_txt v= new fruit_txt(R.drawable.school,"2017-2-2","你好吗",imagePaths,"点赞25次","资助");
            // fruit_txt f1 = new fruit_txt(6,5,4,3,2,1);
            loverlist.add(v);
        }

    }


    private void sss(View view){
        swiperefresh = view.findViewById(R.id.lover_parents_xiala);
        swiperefresh.setColorSchemeResources(R.color.colorPrimary);
        swiperefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Log.e("Refresh","shuaxing");
                refreshFruits();
            }
        });
    }
    private  void refreshFruits(){
        mHanlder.sendEmptyMessageDelayed(0,2000);
    }

    private Handler mHanlder = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){//zhege shi biaoshi
                case 0:
                    Log.e("Refresh","=====");
                    initFruits();
                    adapter.notifyDataSetChanged();
                    swiperefresh.setRefreshing(false);//zhege bushi shuaxin wancheng de fangfa ba
                    break;
            }
        }
    };
}
