package com.example.lenovo.maitianzhuce.parents_jiemian;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.yangshi.zhanshixc_GridAdapter;

import java.util.List;

/**
 * Created by lenovo on 2017/12/14.
 */

public class ParensAdaper extends RecyclerView.Adapter<ParensAdaper.Parens_ViewHolder>{

        private List<fruit_txt> mfruitlist;
        private Context context;
        private zhanshixc_GridAdapter gridAdapter;

            class  Parens_ViewHolder extends RecyclerView.ViewHolder{
            ImageView iamgeid;
            TextView datetime;
            TextView content;
            MyGridView gridcontent;
            TextView zanNum;
            EditText pinglun;


            public Parens_ViewHolder(View itemView) {
                super(itemView);
                iamgeid = (ImageView)itemView.findViewById(R.id.touxiang);
                datetime =(TextView) itemView.findViewById(R.id.time);
                content = (TextView)itemView.findViewById(R.id.cont_text);
                gridcontent = (MyGridView)itemView.findViewById(R.id.parents_gridView_cont);
                zanNum = (TextView)itemView.findViewById(R.id.zan);
                pinglun = (EditText) itemView.findViewById(R.id.pinglun);
            }
        }

    public ParensAdaper(List<fruit_txt> fruitlist, Context context){
        mfruitlist=fruitlist;
        this.context = context;
    }


    //控制子布局
    @Override
    public Parens_ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.dongtai,parent,false);
        Parens_ViewHolder parensView = new Parens_ViewHolder(view);
        return parensView;
    }

    @Override
    public void onBindViewHolder(Parens_ViewHolder holder, int position) {
        //传值数据
        fruit_txt fruit = mfruitlist.get(position);
        holder.iamgeid.setImageResource(fruit.getIamgeid());
        holder.datetime.setText(fruit.getDatetime());
        holder.content.setText(fruit.getContent());

        int cols =context.getResources().getDisplayMetrics().widthPixels / context.getResources().getDisplayMetrics().densityDpi;
        cols = cols < 3 ? 3 : cols;
        holder.gridcontent.setNumColumns(cols);
        gridAdapter = new zhanshixc_GridAdapter(fruit.getZhaopian(), context);
        holder.gridcontent.setAdapter(gridAdapter);

        holder.pinglun.setText(fruit.getComment());
    }
    //布局个数
    @Override
    public int getItemCount(){
        return mfruitlist.size();
    }
}
