package com.example.lenovo.maitianzhuce.parents_jiemian.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.lenovo.maitianzhuce.R;

/**
 * Created by asus on 2017/12/10.
 */

public class xuexiaoActivity extends AppCompatActivity {
    private EditText SchoolName;
    private EditText SchoolPhone;
    private EditText SchoolAddress;
   // private EditText SchoolType;
    private Spinner SchoolType;
    private Button bu_zhuce;
    private CheckBox zc_check=null;



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.school);

        SchoolName = (EditText) findViewById(R.id.s_name);
        SchoolPhone = (EditText) findViewById(R.id.zc_e_yz);
        SchoolAddress = (EditText) findViewById(R.id.s_ad_text);

        SchoolType = (Spinner) findViewById(R.id.s_ca_text);
        String[] mItems = getResources().getStringArray(R.array.xuanze);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, mItems);
        //设置下拉列表的风格
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //绑定 Adapter到控件
        SchoolType .setAdapter(adapter);

        zc_check = (CheckBox) findViewById(R.id.zc_check);
        bu_zhuce = (Button) findViewById(R.id.zc_nextstep);

        bu_zhuce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(SchoolName.length()!=0){
                    if(SchoolPhone.length()!=0){
                        if(SchoolAddress.length()!=0){

                            SchoolType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view,
                                                           int pos, long id) {

                                    String[] languages = getResources().getStringArray(R.array.xuanze);
                                    Toast.makeText(xuexiaoActivity.this, "你选择的是:"+languages[pos],Toast.LENGTH_SHORT ).show();
                                }
                                public void onNothingSelected(AdapterView<?> parent) {
                                    // Another interface callback
                                }
                            });

                                Intent intent = new Intent(xuexiaoActivity.this, DengLu_Activity.class);
                                startActivity(intent);
                                Toast.makeText(xuexiaoActivity.this, "注册成功！", Toast.LENGTH_SHORT).show();

                        }else{
                            Toast.makeText(xuexiaoActivity.this,"请输入学校地址！",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(xuexiaoActivity.this,"请输入学校电话！",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(xuexiaoActivity.this,"请输入学校名称！",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
