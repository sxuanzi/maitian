package com.example.lenovo.maitianzhuce.parents_jiemian;
//通用的VO值

import java.util.ArrayList;

/**
 * Created by lenovo on 2017/12/2.
 */

public class fruit_txt {
    private int iamgeid;
    private String datetime;
    private String content;
    private ArrayList<String> zhaopian;
    private String zanNum;
    private String comment;

    public fruit_txt(int iamgeid, String datetime, String content,ArrayList<String> zhaopian, String zanNum,
                     String comment) {
        super();
        this.iamgeid = iamgeid;
        this.datetime = datetime;
        this.content = content;
        this.zhaopian = zhaopian;
        this.zanNum = zanNum;
        this.comment = comment;
    }
    public int getIamgeid() {
        return iamgeid;
    }
    public void setIamgeid(int iamgeid) {
        this.iamgeid = iamgeid;
    }
    public String getDatetime() {
        return datetime;
    }
    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public ArrayList<String> getZhaopian() {
        return zhaopian;
    }
    public void setZhaopian(ArrayList<String> zhaopian) {
        this.zhaopian = zhaopian;
    }
    public String getZanNum() {
        return zanNum;
    }
    public void setZanNum(String zanNum) {
        this.zanNum = zanNum;
    }
    public String getComment() {
        return comment;
    }
    public void setComment(String  comment) {
        this.comment = comment;
    }

}
