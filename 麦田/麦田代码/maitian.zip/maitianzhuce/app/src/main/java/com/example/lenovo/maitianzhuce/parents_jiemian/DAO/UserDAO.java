package com.example.lenovo.maitianzhuce.parents_jiemian.DAO;

/**
 * Created by asus on 2017/12/7.
 */

public interface UserDAO {

    //传用户名,在数据库中查看是否存在
    public boolean selectUser(String username);

    //传用户名，从数据库拿密码
    public String getPassword(String usrname);
}
