package com.example.lenovo.maitianzhuce.parents_jiemian.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.Bean.UserBean;
import com.example.lenovo.maitianzhuce.parents_jiemian.XiaoHui.XiaoHui;

public class DengLu_Activity extends AppCompatActivity implements View.OnClickListener{

     private String username;
     private String password;
     Button button1;
     EditText user;
     EditText psw;
     TextView zhuce;
     TextView a;
     TextView b;
    //接收上个活动传的身份
     Intent intent;
     public static final int LOGIN_SB = 1;

     private Handler handler = new Handler() {

         public void handleMessage(Message msg) {
             switch (msg.what) {
                 case LOGIN_SB:
                     AlertDialog.Builder dialog = new AlertDialog.Builder(DengLu_Activity.this);
                     dialog.setIcon(getResources().getDrawable(R.drawable.login_error_icon));
                     dialog.setTitle("登录失败");
                     dialog.setMessage("账号或密码错误，请重新输入！");
                     dialog.create();
                     dialog.show();
                     break;

                 default:
                     break;
             }
         }
     };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        XiaoHui.addActivity(this);   //添加一个活动

         a = (TextView) findViewById(R.id.textView);
         b = (TextView) findViewById(R.id.textView2);
         button1 = (Button) findViewById(R.id.register);
         user = (EditText) findViewById(R.id.username);
         psw = (EditText) findViewById(R.id.password);
         zhuce = (TextView) findViewById(R.id.textView2);

         button1.setOnClickListener(this);
         zhuce.setOnClickListener(this);
         a.setOnClickListener(this);
         b.setOnClickListener(this);
    }

            @Override
            public void onClick(View v) {

                intent = getIntent();
                final String identity = intent.getStringExtra("identity");

                UserBean ub = new UserBean();
                int viewId = v.getId();
                switch (viewId) {
                    case R.id.register:
                        Log.e("登录", "点击成功");

                        username = user.getText().toString();
                        password = psw.getText().toString();

                        //判断密码和用户名是否为空
                        // if (("".equals(username) || null == username) || ("".equals(password) || null == password)) {
                        if(user.getText().length() == 11){
                            if(psw.getText().length() != 0){
                                denglu();
                            } else {
                                Toast.makeText(DengLu_Activity.this, "请输入密码！", Toast.LENGTH_SHORT).show();
                            }
                        } else{
                            Toast.makeText(DengLu_Activity.this,"请输入十一位的手机号",Toast.LENGTH_SHORT).show();
                        }
                        break;

                        //忘记密码
                    case  R.id.textView:
                        Intent intent = new Intent(DengLu_Activity.this, MainActivity.class);
                        startActivity(intent);
                        break;

                        //注册
                    case R.id.textView2:
                        if("学校".equals(identity)){
                            //学校注册
                            Intent intent1 = new Intent(DengLu_Activity.this, xuexiaoActivity.class);
                            intent1.putExtra("identity",identity);
                            startActivity(intent1);

                        }else{
                            //爱心人士、家长注册
                            Intent intent1 = new Intent(DengLu_Activity.this, otherZhuCe_Activity.class);
                            intent1.putExtra("identity",identity);
                            startActivity(intent1);

                        }
                        break;

                    default:
                         break;
                }
           }


           private void denglu() {

               new Thread(new Runnable() {
                   @Override
                   public void run() {
                       String u = username;
                       String p = password;

                       UserBean ub = new UserBean();


                       try {

                        //   Response response = client.newCall(request).execute();
                           if (ub.isLogin(u, p)) {
                               intent = getIntent();
                               String identity = intent.getStringExtra("identity");

                              if ("家长".equals(identity)) {
                                   Intent intent = new Intent(DengLu_Activity.this, ParentsJm.class);
                                   startActivity(intent);

                              }else if ("爱心人士".equals(identity)) {
                                   Intent intent = new Intent(DengLu_Activity.this,LoverJm.class);
                                   startActivity(intent);

                               }else if ("学校".equals(identity)) {
                                   Intent intent = new Intent(DengLu_Activity.this, TeacherJm.class);
                                   startActivity(intent);
                               }

                               //销毁之前所有活动
                               XiaoHui.finishAll();
                               Log.e("登录", "登录成功！");
                           } else {
                               Log.e("登录", "没有此用户，登录失败！" );
                                //发送消息给主线程，返回执行结果，（登陆失败）
                               Message message = new Message();
                               message.what = LOGIN_SB;
                               handler.sendMessage(message);

                           }

                       } catch ( Exception e){
                           e.printStackTrace();
                       }
                   }
               }).start();
           }
}

