package com.example.lenovo.maitianzhuce.parents_jiemian;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.yangshi.zhanshixc_GridAdapter;

import java.util.List;
//动态子布局


public class LoverAdapter extends RecyclerView.Adapter<LoverAdapter.lover_ViewHolder>{

    private List<fruit_txt> mfruitlist;
    private Context context;
    private zhanshixc_GridAdapter gridAdapter;

     class  lover_ViewHolder extends RecyclerView.ViewHolder{
        ImageView iamgeid;
         TextView datetime;
         TextView content;
         MyGridView gridcontent;
         TextView zanNum;
         Button button;


         public lover_ViewHolder(View itemView) {

             super(itemView);  //你这个布局的这个id是lover_touxiang
             iamgeid = (ImageView)itemView.findViewById(R.id.lover_touxiang);
             datetime =(TextView) itemView.findViewById(R.id.lover_time);
             content = (TextView)itemView.findViewById(R.id.lover_cont);
             gridcontent = (MyGridView)itemView.findViewById(R.id.lover_gridView_cont);
             zanNum = (TextView)itemView.findViewById(R.id.lover_zan);
             button = (Button) itemView.findViewById(R.id.lover_zizhu);

         }
     }

    public LoverAdapter(List<fruit_txt> fruitlist,Context context){

         mfruitlist=fruitlist;
         this.context = context;
    }

    @Override
    public lover_ViewHolder onCreateViewHolder(ViewGroup parent, int viewtype){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lover_dongtai,parent,false);
        lover_ViewHolder  holder = new lover_ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(lover_ViewHolder holder, int position) {
        fruit_txt fruit = mfruitlist.get(position);
        holder.iamgeid.setImageResource(fruit.getIamgeid());
        holder.datetime.setText(fruit.getDatetime());
        holder.content.setText(fruit.getContent());

        int cols =context.getResources().getDisplayMetrics().widthPixels / context.getResources().getDisplayMetrics().densityDpi;
        cols = cols < 3 ? 3 : cols;
        holder.gridcontent.setNumColumns(cols);
        gridAdapter = new zhanshixc_GridAdapter(fruit.getZhaopian(), context);
        holder.gridcontent.setAdapter(gridAdapter);

        holder.button.setText(fruit.getComment());
        return;
    }


    @Override
    public int getItemCount(){
        return mfruitlist.size();
    }

}
