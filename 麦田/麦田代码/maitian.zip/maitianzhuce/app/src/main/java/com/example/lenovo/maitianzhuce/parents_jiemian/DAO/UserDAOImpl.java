package com.example.lenovo.maitianzhuce.parents_jiemian.DAO;

import android.util.Log;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by asus on 2017/12/7.
 */

public class UserDAOImpl implements UserDAO {
    @Override
    public boolean selectUser(String username) {
        Connection con = null;
        con = DBConnection.getConnection();
       // String psw = "";
        boolean d = false;

        if (con != null) {
            String sql = "select * from tUser where username='" + username + "'";
            try {
                Statement s = con.createStatement();
                ResultSet rs = s.executeQuery(sql);
                if (rs.next()) {
                    Log.e("用户名", rs.getString("username") + "\t" + rs.getString("psw") + "\t");
                    d = true;
                }else {
                    d = false;
                }

            } catch (SQLException e) {
                Log.e("数据库连接", "不好意思，出错了");
            } finally {
                DBConnection.closeConnection(con);
            }
        }
        return d;
    }


    public String getPassword(String usrname) {
        String sql = "select * from tUser where username='"+ usrname +"'";
        Connection con = null;
        String p = null;

        try {
            con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if (rs.next())
                p = rs.getString("psw");

        }catch (Exception e) {
            System.out.println("通过用户名，在数据库找到密码，并返回，但出错了！");
            e.printStackTrace();
        }finally {
            DBConnection.closeConnection(con);
        }

        return p;
    }
}

