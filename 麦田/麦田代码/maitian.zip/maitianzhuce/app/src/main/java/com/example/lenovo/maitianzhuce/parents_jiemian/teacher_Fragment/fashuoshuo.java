package com.example.lenovo.maitianzhuce.parents_jiemian.teacher_Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.yangshi.FinishProjectPopupWindows;
import com.example.lenovo.maitianzhuce.parents_jiemian.yangshi.zhanshixc_GridAdapter;
import com.lidong.photopicker.PhotoPickerActivity;
import com.lidong.photopicker.PhotoPreviewActivity;
import com.lidong.photopicker.SelectModel;
import com.lidong.photopicker.intent.PhotoPickerIntent;

import org.json.JSONArray;

import java.util.ArrayList;

/**
 * Created by lenovo on 2017/12/16.
 */

public class fashuoshuo extends AppCompatActivity implements View.OnClickListener{
    private static final int REQUEST_CAMERA_CODE = 10;
    private static final int REQUEST_PREVIEW_CODE = 20;

    private ArrayList<String> imagePaths = new ArrayList<>();
    private String cont=null;

    private GridView gridView;
    private zhanshixc_GridAdapter gridAdapter;
    private EditText textView;
    private TextView tv_OK;
    ImageView faimage;
    //实现底部弹出拍照选择功能
    private FinishProjectPopupWindows mFinishProjectPopupWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        ActionBar actionbar = getSupportActionBar();
        if (actionbar !=null){actionbar.hide();}
        setContentView(R.layout.fabiao);

        tv_OK = (TextView) findViewById(R.id.tv_ok);
        gridView = (GridView) findViewById(R.id.teacher_gridView);
        faimage =  findViewById(R.id.faimage);
        textView = findViewById(R.id.teacher_cont);//这个  控件在这个布局不对啊

        int cols = getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().densityDpi;
        cols = cols < 3 ? 3 : cols;
        gridView.setNumColumns(cols);

        //展示照片的适配器
        gridAdapter = new zhanshixc_GridAdapter(imagePaths,fashuoshuo.this);
        gridView.setAdapter(gridAdapter);

        tv_OK.setOnClickListener(this);
        faimage.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.faimage:
                mFinishProjectPopupWindow = new FinishProjectPopupWindows(fashuoshuo.this, itemsOnClick);
                mFinishProjectPopupWindow.showAtLocation(view, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
                break;

            case R.id.tv_ok:
                cont=textView.getText().toString();
                Intent intent = new Intent();
                Log.e("选中的图片:",imagePaths.size()+"");
                intent.putExtra("imagePaths",imagePaths);
                intent.putExtra("textcont",cont);
                setResult(0,intent);
                finish();


        }
    }

    private View.OnClickListener itemsOnClick = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            mFinishProjectPopupWindow.dismiss();
            switch(v.getId()){
                case R.id.xiangc:
                        PhotoPickerIntent intent = new PhotoPickerIntent(fashuoshuo.this);
                        intent.setSelectModel(SelectModel.MULTI);
                        intent.setShowCarema(true); // 是否显示拍照
                        intent.setMaxTotal(9); // 最多选择照片数量，默认为9
                        intent.setSelectedPaths(imagePaths); // 已选中的照片地址， 用于回显选中状态
                        startActivityForResult(intent, REQUEST_CAMERA_CODE);

                        break;
                case R.id.paishe:
                    Log.i("TAG", "摄像");
                    break;
                case R.id.quxiao:
                    //退出
                    mFinishProjectPopupWindow.dismiss();
                    Log.i("TAG", "取消");
            break;
        }

        }

    };


    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            switch (requestCode) {
                // 选择照片
                case REQUEST_CAMERA_CODE:
                    ArrayList<String> list = data.getStringArrayListExtra(PhotoPickerActivity.EXTRA_RESULT);

                    loadAdpater(list);
                    break;
                // 预览
                case REQUEST_PREVIEW_CODE:
                    ArrayList<String> ListExtra = data.getStringArrayListExtra(PhotoPreviewActivity.EXTRA_RESULT);
                    loadAdpater(ListExtra);
                    break;
            }
        }
    }

    private void loadAdpater(ArrayList<String> paths){
        if (imagePaths!=null&& imagePaths.size()>0){
            imagePaths.clear();
        }
        if (paths.contains("paizhao")){
            paths.remove("paizhao");
        }
//        paths.add("paizhao");
        imagePaths.addAll(paths);
        gridAdapter  = new zhanshixc_GridAdapter(imagePaths,fashuoshuo.this);
        gridView.setAdapter(gridAdapter);
        try{
            JSONArray obj = new JSONArray(imagePaths);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
