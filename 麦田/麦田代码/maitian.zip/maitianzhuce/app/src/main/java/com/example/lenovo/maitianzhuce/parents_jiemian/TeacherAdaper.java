package com.example.lenovo.maitianzhuce.parents_jiemian;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.yangshi.zhanshixc_GridAdapter;

import java.util.List;

/**
 * Created by lenovo on 2017/12/15.
 *
 */

public class TeacherAdaper extends RecyclerView.Adapter<TeacherAdaper.Teacher_ViewHolder>{

    private List<fruit_txt> mfruitlist;
    private zhanshixc_GridAdapter gridAdapter;
    private Context context;

    class  Teacher_ViewHolder extends RecyclerView.ViewHolder{
        ImageView iamgeid;
        TextView datetime;
        TextView content;
        MyGridView gridcontent;
        TextView zanNum;
        EditText pinglun;


        public Teacher_ViewHolder(View itemView) {
            super(itemView);
            iamgeid = (ImageView)itemView.findViewById(R.id.teacher_touxiang);
            datetime =(TextView) itemView.findViewById(R.id.teacher_time);
            content = (EditText)itemView.findViewById(R.id.teacher_cont);
        //    gridcontent = MyGridView(context,itemView.findViewById(R.id.teacher_gridView_cont));
            gridcontent = (MyGridView)itemView.findViewById(R.id.teacher_gridView_cont);
            zanNum = (TextView)itemView.findViewById(R.id.teacher_zan);
            pinglun = (EditText) itemView.findViewById(R.id.teacher_pinglun);
        }
    }

    public TeacherAdaper(List<fruit_txt> fruitlist, Context context){
        mfruitlist=fruitlist;
        this.context = context;
    }


    @Override
    public Teacher_ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.teacher_dongtai,parent,false);
        Teacher_ViewHolder parensView = new Teacher_ViewHolder(view);
        return parensView;
    }

    @Override
    public void onBindViewHolder(Teacher_ViewHolder holder, int position) {
        fruit_txt fruit = mfruitlist.get(position);
        holder.iamgeid.setImageResource(fruit.getIamgeid());
        holder.datetime.setText(fruit.getDatetime());
        holder.content.setText(fruit.getContent());
//        照片适配
        int cols =context.getResources().getDisplayMetrics().widthPixels / context.getResources().getDisplayMetrics().densityDpi;
        cols = cols < 3 ? 3 : cols;
        holder.gridcontent.setNumColumns(cols);
        gridAdapter = new zhanshixc_GridAdapter(fruit.getZhaopian(), context);
        holder.gridcontent.setAdapter(gridAdapter);

        holder.pinglun.setText(fruit.getComment());
    }


    @Override
    public int getItemCount(){
        return mfruitlist.size();
    }



}
