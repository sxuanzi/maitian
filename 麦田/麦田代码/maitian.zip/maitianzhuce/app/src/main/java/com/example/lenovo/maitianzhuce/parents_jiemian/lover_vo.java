package com.example.lenovo.maitianzhuce.parents_jiemian;

/**
 * Created by lenovo on 2017/12/15.
 */

public class lover_vo {
    private int iamgeid;
    private String datetime;
    private String content;
    private String zanNum;
    private String liunum;
    private String pinglun;

    public lover_vo(int iamgeid, String datetime, String content, String zanNum,
                     String liunum, String pinglun) {
        super();
        this.iamgeid = iamgeid;
        this.datetime = datetime;
        this.content = content;
        this.zanNum = zanNum;
        this.liunum = liunum;
        this.pinglun = pinglun;
    }
    public int getIamgeid() {
        return iamgeid;
    }
    public void setIamgeid(int iamgeid) {
        this.iamgeid = iamgeid;
    }
    public String getDatetime() {
        return datetime;
    }
    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getZanNum() {
        return zanNum;
    }
    public void setZanNum(String zanNum) {
        this.zanNum = zanNum;
    }
    public String getLiunum() {
        return liunum;
    }
    public void setLiunum(String liunum) {
        this.liunum = liunum;
    }
    public String getPinglun() {
        return pinglun;
    }
    public void setPinglun(String  comment) {
        this.pinglun = comment;
    }
}
