package com.example.lenovo.maitianzhuce.parents_jiemian;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import com.example.lenovo.maitianzhuce.R;
/**
 * Created by lenovo on 2017/12/2.
 */
//实现头部标题栏
public class TitleLayout extends LinearLayout {
    @SuppressLint("ResourceType")
    public TitleLayout(Context context, AttributeSet attrs){
        super(context,attrs);
       LayoutInflater.from(context).inflate(R.id.title_zhuce,this);

    }
}
