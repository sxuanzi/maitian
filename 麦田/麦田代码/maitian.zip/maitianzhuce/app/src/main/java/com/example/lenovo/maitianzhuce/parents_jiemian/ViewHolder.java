package com.example.lenovo.maitianzhuce.parents_jiemian;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lenovo.maitianzhuce.R;

/**
 * Created by lenovo on 2017/12/13.
 */

public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView iamgeid;
        TextView datetime;
        TextView content;
        TextView zanNum;
        EditText pinglun;
        Button lover_zizhu;


        public ViewHolder(View itemView, int type) {
                super(itemView);
                //你这个布局的这个id是lover_touxiang
                if(type==1){
                        parents();
                }else if(type==2){
                        lover();
                }

        }

        public void parents(){
                iamgeid = (ImageView)itemView.findViewById(R.id.touxiang);
                datetime =(TextView) itemView.findViewById(R.id.time);
                content = (TextView)itemView.findViewById(R.id.cont_text);
                zanNum = (TextView)itemView.findViewById(R.id.zan);
                pinglun = (EditText) itemView.findViewById(R.id.pinglun);
        }

        public void lover(){
                iamgeid = (ImageView)itemView.findViewById(R.id.lover_touxiang);
                datetime =(TextView) itemView.findViewById(R.id.lover_time);
                content = (TextView)itemView.findViewById(R.id.lover_cont);
                zanNum = (TextView)itemView.findViewById(R.id.lover_zan);
                lover_zizhu = (Button) itemView.findViewById(R.id.lover_zizhu);
        }
}

