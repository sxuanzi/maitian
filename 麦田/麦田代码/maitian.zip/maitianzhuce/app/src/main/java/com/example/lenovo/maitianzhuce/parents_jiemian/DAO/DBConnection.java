package com.example.lenovo.maitianzhuce.parents_jiemian.DAO;

import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {


    /**
     *
     * @return
     */
    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            Log.e("驱动加载", "加载驱动jtds成功");
        } catch (ClassNotFoundException e) {
            Log.e("驱动加载", "加载jtds驱动失败");
            return null;
        }

        try {
             //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection("jdbc:jtds:sqlserver://175.1.79.216:1433;DatabaseName=MaTian", "sa", "m123");
            Log.e("数据库连接", "数据库连接成功!");
        } catch (SQLException e) {
            Log.e("数据库连接", "数据库连接失败!");
        }
        return con;
    }


    /**
     *
     * @param con
     */
    public static void closeConnection(Connection con) {
        try {
            if (con != null)
                con.close();
        }catch (SQLException e) {
            Log.e("关闭连接", "关闭连接失败");
        }
    }

}
