package com.example.lenovo.maitianzhuce.parents_jiemian.teacher_Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import com.example.lenovo.maitianzhuce.R;
import com.example.lenovo.maitianzhuce.parents_jiemian.TeacherAdaper;
import com.example.lenovo.maitianzhuce.parents_jiemian.fruit_txt;

import java.util.ArrayList;
import java.util.List;

/*点击动态包裹的碎片跳转到此页面
这个页面包裹的是标题栏
 */

public class DynamiceFragment extends Fragment implements View.OnClickListener {


    private List<fruit_txt> teacherlist = new ArrayList<>();
    private static final int ZHAOPIAN_FABUDONGTAI = 30;
    private SwipeRefreshLayout swiperefresh;
    GridView gridView = null;
    private Button teacher_fabiao;
    private ArrayList<String> imagePaths = new ArrayList<>();
    private  String textcont;
    private  String pinglun;

    TeacherAdaper adapter;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //把动态的主页面传给view
        View view = inflater.inflate(R.layout.teacher_dynamics_main,null);

        //获取发表的按钮
        teacher_fabiao = view.findViewById(R.id.teacher_fabiao);


        initData(view);  //recycleView  适配器
        shuaxin(view);   //刷新

        teacher_fabiao.setOnClickListener(this);
        return view;
    }

    public void initData(View view){
        //初始化控件，源数据
        initFruits();
        RecyclerView recycleView = view.findViewById(R.id.teacher_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recycleView.setLayoutManager(layoutManager);
        adapter=new TeacherAdaper(teacherlist,getActivity());  //你这个刷新控件绑定的是这个adapter啊
        recycleView.setAdapter(adapter);
    }

    private void initFruits(){
        for (int i=1;i<=1;i++) {
            fruit_txt v = new fruit_txt(R.drawable.school, "2017-2-2", textcont, imagePaths, "点赞25次","111");
            // fruit_txt f1 = new fruit_txt(6,5,4,3,2,1);日志一上去
            teacherlist.add(v);
        }
    }


    private void shuaxin(View view){
        swiperefresh = view.findViewById(R.id.teacher_parents_xiala);
        swiperefresh.setColorSchemeResources(R.color.colorPrimary);
        swiperefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Log.e("Refresh","shuaxing");
                teacherlist.clear();
                refreshFruits();

            }
        });
    }
    private  void refreshFruits(){
        mHanlder.sendEmptyMessageDelayed(0,2000);
    }
    //刷新
    private Handler mHanlder = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){//zhege shi biaoshi
                case 0:
                    Log.e("Refresh","=====");
                    initFruits();

                    Log.e("imagePaths2:",imagePaths.size()+"");
                    adapter.notifyDataSetChanged();
                    swiperefresh.setRefreshing(false);//zhege bushi shuaxin wancheng de fangfa ba

                    break;
            }
        }
    };


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.teacher_fabiao:
                Intent intent = new Intent(getActivity(),fashuoshuo.class);
                startActivityForResult(intent, ZHAOPIAN_FABUDONGTAI);
                break;
        }
    }

    //返回值
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data==null){
            return;
        }
        switch (requestCode){//你手机没进来啊可是我能看到它运行啊
            case ZHAOPIAN_FABUDONGTAI:
                Log.e("进来了","======"+resultCode);
                if (resultCode == 0){//选择试试选完啦发完了再来
                    imagePaths = data.getStringArrayListExtra("imagePaths");
                    textcont = data.getStringExtra("textcont");
                    Log.e("imagePaths:",imagePaths.size()+"");
                    refreshFruits();
                }
             break;

        }


    }
}
