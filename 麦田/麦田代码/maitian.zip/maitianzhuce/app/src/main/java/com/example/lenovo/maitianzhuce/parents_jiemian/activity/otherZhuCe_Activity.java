package com.example.lenovo.maitianzhuce.parents_jiemian.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.lenovo.maitianzhuce.R;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;
//import com.yanzhengma.yzm;


/**
 * Created by asus on 2017/12/6.
 */

public class otherZhuCe_Activity extends AppCompatActivity implements View.OnClickListener{
    private EditText etPhoneNumber;        // 电话号码
    private Button sendVerificationCode;   // 发送验证码
    private EditText etVerificationCode;   // 验证码
    private Button nextStep;               // 下一步
    private boolean re = false;
    private String phoneNumber;         // 电话号码
    private String verificationCode;    // 验证码
    private boolean flag;   // 操作是否成功
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yanzhengma);
        init(); // 初始化控件、注册点击事件
        final Context context = otherZhuCe_Activity.this;                       // context
        final String AppKey = "22c5a3affe180";                       // AppKey
        final String AppSecret = "1088ba8b2cf6c0c53a480e48b98b9dc8"; // AppSecret
        SMSSDK.initSDK(context, AppKey, AppSecret);
        EventHandler eventHandler = new EventHandler(){       // 操作回调
            @Override
            public void afterEvent(int event, int result, Object data) {
                Message msg = new Message();
                msg.arg1 = event;
                msg.arg2 = result;
                msg.obj = data;
                handler.sendMessage(msg);
            }
        };
        SMSSDK.registerEventHandler(eventHandler);     // 注册回调接口
    }

    private void init() {
        etPhoneNumber = (EditText) findViewById(R.id.login_e_username);
        sendVerificationCode = (Button) findViewById(R.id.login_bu_yz);
        etVerificationCode = (EditText) findViewById(R.id.login_e_yz);
        nextStep = (Button) findViewById(R.id.login_zc);
        sendVerificationCode.setOnClickListener(this);
        nextStep.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        CountDownTimer timeCountUtil;
        timeCountUtil = new daojishi(this, 60000, 1000, sendVerificationCode);
        //timeCountUtil.start();
        switch (v.getId()) {
            case R.id.login_bu_yz:
                if (!TextUtils.isEmpty(etPhoneNumber.getText())) {
                    if (etPhoneNumber.getText().length() == 11) {
                        //pd();
                        //if(re){
                        //    Toast.makeText(this, "用户名已存在！", Toast.LENGTH_SHORT).show();
                       // }else{
                            phoneNumber = etPhoneNumber.getText().toString();
                            SMSSDK.getVerificationCode("86", phoneNumber); // 发送验证码给号码的 phoneNumber 的手机
                            etVerificationCode.requestFocus();
                            timeCountUtil.start();
                       // }
                    }
                    else {
                        Toast.makeText(this, "请输入完整的电话号码", Toast.LENGTH_SHORT).show();
                        etPhoneNumber.requestFocus();
                    }
                } else {
                    Toast.makeText(this, "请输入电话号码", Toast.LENGTH_SHORT).show();
                    etPhoneNumber.requestFocus();
                }
                break;

            case R.id.login_zc:
                if (!TextUtils.isEmpty(etVerificationCode.getText())) {
                    if (etVerificationCode.getText().length() == 4) {
                        verificationCode = etVerificationCode.getText().toString();
                        SMSSDK.submitVerificationCode("86", phoneNumber, verificationCode);
                        flag = false;
                    } else {
                        Toast.makeText(this, "请输入完整的验证码", Toast.LENGTH_SHORT).show();
                        etVerificationCode.requestFocus();
                    }
                } else {
                    Toast.makeText(this, "请输入验证码", Toast.LENGTH_SHORT).show();
                    etVerificationCode.requestFocus();
                }
                break;

            default:
                break;
        }
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            int event = msg.arg1;
            int result = msg.arg2;
            Object data = msg.obj;
            intent = getIntent();
            final String identity = intent.getStringExtra("identity");
            if (result == SMSSDK.RESULT_COMPLETE) {
                // 如果操作成功
                if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                    // 校验验证码，返回校验的手机和国家代码
                    Intent intent = new Intent(otherZhuCe_Activity.this, parents_lover_MainActivity.class);
                    intent.putExtra("identity",identity);
                    startActivity(intent);
                } else if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
                    // 获取验证码成功，true为智能验证，false为普通下发短信
                    Toast.makeText(otherZhuCe_Activity.this, "验证码已发送", Toast.LENGTH_SHORT).show();
                } else if (event == SMSSDK.EVENT_GET_SUPPORTED_COUNTRIES) {
                    // 返回支持发送验证码的国家列表
                }
            } else {
                // 如果操作失败
                if (flag) {
                    Toast.makeText(otherZhuCe_Activity.this, "验证码获取失败，请重新获取", Toast.LENGTH_SHORT).show();
                    etPhoneNumber.requestFocus();
                } else {
                    ((Throwable) data).printStackTrace();
                    Toast.makeText(otherZhuCe_Activity.this, "验证码错误", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SMSSDK.unregisterAllEventHandler();  // 注销回调接口
    }

 /*   private void pd() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                phoneNumber = etPhoneNumber.getText().toString().trim();
                String u = phoneNumber;
                UserBean ub = new UserBean();
                re = ub.panduan(u);
            }
        }).start();
    }*/
}