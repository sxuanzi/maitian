package com.example.lenovo.maitianzhuce.parents_jiemian.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.lenovo.maitianzhuce.R;
import com.mob.mobapi.API;
import com.mob.mobapi.APICallback;
import com.mob.mobapi.MobAPI;
import com.mob.mobapi.apis.IDCard;
import com.mob.tools.utils.ResHelper;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by asus on 2017/12/10.
 */

public class parentsNextActivity extends Activity implements View.OnClickListener, APICallback {
    private EditText sfznumber; //身份证号码
    private EditText xuehao;//学号
    private EditText xuexiao;//学校zc_e_school
    private EditText diqu;//地区zc_e_address
    private EditText teacherTelephone;//班主任电话号码zc_e_teacherH

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parents_next);
        sfznumber = (EditText) findViewById(R.id.zc_e_code);
        xuehao = (EditText) findViewById(R.id.zc_e_student);
        xuexiao = (EditText) findViewById(R.id.zc_e_school);
        diqu = (EditText) findViewById(R.id.zc_e_address);
        teacherTelephone = (EditText) findViewById(R.id.zc_e_teacherH);
        findViewById(R.id.zc_nextstep).setOnClickListener(this);
    }
    public void onClick(View v) {
        // 获取API实例，查询身份证信息
        IDCard api = ResHelper.forceCast(MobAPI.getAPI(IDCard.NAME));
        api.queryIDCard(sfznumber.getText().toString().trim(), this);
    }

    public void onSuccess(API api, int action, Map<String, Object> result) {
        HashMap<String, Object> address = ResHelper.forceCast(result.get("result"));
        if(xuehao.length()!=0&&xuexiao.length()==12){
            if(xuexiao.equals("湖南软件职业学院")){
                if(teacherTelephone.length()!=0&&teacherTelephone.length()==11){
                    Intent intent=new Intent(parentsNextActivity.this,DengLu_Activity.class);
                    startActivity(intent);
                    Toast.makeText(this,"注册成功！", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(this,"请输入十一位电话号码！", Toast.LENGTH_SHORT).show();
                }
            }else {
                Toast.makeText(this,"请输入正确的学校！", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this,"注册失败，请输入十二位的学号！", Toast.LENGTH_SHORT).show();
        }
    }

    public void onError(API api, int action, Throwable details) {
        details.printStackTrace();
        Toast.makeText(this,"查询不到该身份证信息！", Toast.LENGTH_SHORT).show();
    }
}
