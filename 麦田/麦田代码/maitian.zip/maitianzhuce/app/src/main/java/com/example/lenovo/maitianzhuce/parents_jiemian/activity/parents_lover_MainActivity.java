package com.example.lenovo.maitianzhuce.parents_jiemian.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.lenovo.maitianzhuce.R;

/**
 * Created by asus on 2017/12/27.
 */

public class parents_lover_MainActivity extends AppCompatActivity {
    private EditText nichen;
    private EditText psw;
    private EditText zpsw;
    private Button button_next;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parents_lover);
        nichen = (EditText) findViewById(R.id.zc_e_name);
        psw = (EditText) findViewById(R.id.zc_e_psw);
        zpsw = (EditText) findViewById(R.id.zc_e_zpsw);
        button_next = (Button) findViewById(R.id.zc_nextstep);
        intent = getIntent();
        final String identity = intent.getStringExtra("identity");

        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nichen.length()<=16 && nichen.length()!=0){
                    //if(psw.equals(zpsw)){
                        if("家长".equals(identity)){
                            Intent intent = new Intent(parents_lover_MainActivity.this, parentsNextActivity.class);
                            startActivity(intent);
                        } else if ("爱心人士".equals(identity)){
                            Intent intent = new Intent(parents_lover_MainActivity.this, loverNextActivity.class);
                            startActivity(intent);
                        }
                    //}else{
                     //  Toast.makeText(parents_lover_MainActivity.this,"两次输入的密码不正确！",Toast.LENGTH_SHORT).show();
                   // }
                }else{
                    Toast.makeText(parents_lover_MainActivity.this,"请输入小于16个字节的昵称（字母数字一个为一个字节，汉字一个为两个字节）！",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
