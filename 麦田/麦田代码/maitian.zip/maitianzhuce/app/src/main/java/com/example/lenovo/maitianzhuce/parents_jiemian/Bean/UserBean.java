package com.example.lenovo.maitianzhuce.parents_jiemian.Bean;

import com.example.lenovo.maitianzhuce.parents_jiemian.DAO.UserDAO;
import com.example.lenovo.maitianzhuce.parents_jiemian.DAO.UserDAOImpl;

/**
 * Created by asus on 2017/12/7.
 */

public class UserBean {

    public boolean isLogin(String u,String p) {

        UserDAO us = new UserDAOImpl();
        // psw = us.selectUser(u);
        if(us.selectUser(u)) {
          if(p.equals(us.getPassword(u))){
               return true;
           } else {
              return  false;
          }
        }
        else{
            return false;
        }
    }
}
