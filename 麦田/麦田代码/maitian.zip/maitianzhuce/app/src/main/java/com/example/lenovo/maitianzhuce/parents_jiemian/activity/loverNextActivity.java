package com.example.lenovo.maitianzhuce.parents_jiemian.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.lenovo.maitianzhuce.R;
import com.mob.mobapi.API;
import com.mob.mobapi.APICallback;
import com.mob.mobapi.MobAPI;
import com.mob.mobapi.apis.IDCard;
import com.mob.tools.utils.ResHelper;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by asus on 2017/12/10.
 */

public class loverNextActivity extends Activity implements View.OnClickListener, APICallback {
    private EditText sfznumber; //身份证号码
    private EditText address;//地址
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lover_next);
        sfznumber = (EditText) findViewById(R.id.zc_e_Lcode);
        address = (EditText) findViewById(R.id.zc_e_Laddress);
        findViewById(R.id.zc_Lnextstep).setOnClickListener(this);
    }
    public void onClick(View v) {
        // 获取API实例，查询身份证信息
        IDCard api = ResHelper.forceCast(MobAPI.getAPI(IDCard.NAME));
        api.queryIDCard(sfznumber.getText().toString().trim(), this);
    }

    public void onSuccess(API api, int action, Map<String, Object> result) {
        HashMap<String, Object> address = ResHelper.forceCast(result.get("result"));
        if(address.size()!=0){
            Intent intent=new Intent(loverNextActivity.this,DengLu_Activity.class);
            startActivity(intent);
            Toast.makeText(this,"注册成功！", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this,"请输入你的地址！！", Toast.LENGTH_SHORT).show();
        }
    }

    public void onError(API api, int action, Throwable details) {
        details.printStackTrace();
        Toast.makeText(this,"查询不到该身份证信息！", Toast.LENGTH_SHORT).show();
    }

}
